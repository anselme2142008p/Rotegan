import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

class TicTacToe extends BoardGame {
  final List<int> _cells = List.filled(9, -1);
  int _current = 0;
  int? _winner;
  bool _over = false;

  static const _lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];

  @override
  int get currentPlayer => _current;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over
      ? []
      : [
          for (var i = 0; i < 9; i++)
            if (_cells[i] == -1) {'cell': i}
        ];

  @override
  void play(Move move) {
    _cells[move['cell'] as int] = _current;
    final w = _evaluate(_cells);
    if (w != null) {
      _winner = w;
      _over = true;
    } else if (!_cells.contains(-1)) {
      _over = true;
    } else {
      _current = 1 - _current;
    }
  }

  static int? _evaluate(List<int> b) {
    for (final l in _lines) {
      if (b[l[0]] != -1 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) {
        return b[l[0]];
      }
    }
    return null;
  }

  @override
  Move botMove(Random rnd) {
    final moves = legalMoves();
    // 1 coup sur 5 est aléatoire pour que le bot reste battable.
    if (rnd.nextDouble() < 0.2) return moves[rnd.nextInt(moves.length)];
    final me = _current;
    var best = -2;
    final bestCells = <int>[];
    for (final m in moves) {
      final i = m['cell'] as int;
      final board = List<int>.from(_cells);
      board[i] = me;
      final score = _minimax(board, 1 - me, me);
      if (score > best) {
        best = score;
        bestCells
          ..clear()
          ..add(i);
      } else if (score == best) {
        bestCells.add(i);
      }
    }
    return {'cell': bestCells[rnd.nextInt(bestCells.length)]};
  }

  static int _minimax(List<int> b, int turn, int me) {
    final w = _evaluate(b);
    if (w != null) return w == me ? 1 : -1;
    if (!b.contains(-1)) return 0;
    var best = turn == me ? -2 : 2;
    for (var i = 0; i < 9; i++) {
      if (b[i] != -1) continue;
      b[i] = turn;
      final s = _minimax(b, 1 - turn, me);
      b[i] = -1;
      best = turn == me ? max(best, s) : min(best, s);
    }
    return best;
  }

  @override
  String describe() => [
        for (var r = 0; r < 3; r++)
          [for (var c = 0; c < 3; c++) _cells[r * 3 + c] == -1 ? '.' : (_cells[r * 3 + c] == 0 ? 'X' : 'O')].join(' ')
      ].join('\n');

  @override
  Widget buildBoard(
    BuildContext context, {
    required bool canPlay,
    required void Function(Move) onMove,
  }) {
    return AspectRatio(
      aspectRatio: 1,
      child: GridView.count(
        crossAxisCount: 3,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        padding: const EdgeInsets.all(8),
        children: [
          for (var i = 0; i < 9; i++)
            Material(
              color: Theme.of(context).colorScheme.secondaryContainer,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: (canPlay && _cells[i] == -1 && !_over)
                    ? () => onMove({'cell': i})
                    : null,
                child: Center(
                  child: Text(
                    _cells[i] == -1 ? '' : (_cells[i] == 0 ? 'X' : 'O'),
                    style: TextStyle(
                      fontSize: 38,
                      fontWeight: FontWeight.bold,
                      color: _cells[i] == 0
                          ? Colors.red.shade600
                          : Colors.blue.shade700,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
