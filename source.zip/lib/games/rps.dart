import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Pierre-feuille-ciseaux : le premier à 3 manches gagne. Coup = {'p': 0 pierre, 1 feuille, 2 ciseaux}.
class Rps extends BoardGame {
  static const _e = ['✊', '✋', '✌️'];
  final List<int?> _picks = [null, null];
  final List<int> _sc = [0, 0];
  int _cur = 0;
  int? _winner;
  bool _over = false;
  String _last = '';

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over ? [] : [for (var i = 0; i < 3; i++) {'p': i}];

  @override
  void play(Move move) {
    _picks[_cur] = move['p'] as int;
    if (_cur == 0) {
      _cur = 1;
      return;
    }
    final a = _picks[0]!, b = _picks[1]!, d = (a - b + 3) % 3;
    _last = 'A ${_e[a]} · B ${_e[b]} → ${d == 0 ? 'égalité' : (d == 1 ? 'A gagne la manche' : 'B gagne la manche')}';
    if (d == 1) {
      _sc[0]++;
    } else if (d == 2) {
      _sc[1]++;
    }
    _picks[0] = null;
    _picks[1] = null;
    _cur = 0;
    if (_sc[0] == 3 || _sc[1] == 3) {
      _over = true;
      _winner = _sc[0] == 3 ? 0 : 1;
    }
  }

  @override
  Move botMove(Random rnd) => {'p': rnd.nextInt(3)};

  @override
  String describe() => 'Manches : A ${_sc[0]} – B ${_sc[1]}. $_last';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    return Column(children: [
      Text('Manches — A : ${_sc[0]} · B : ${_sc[1]} (3 pour gagner)'),
      if (_last.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(_last, textAlign: TextAlign.center)),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (var i = 0; i < 3; i++)
          Padding(
            padding: const EdgeInsets.all(6),
            child: OutlinedButton(
              onPressed: canPlay && !_over ? () => onMove({'p': i}) : null,
              child: Text(_e[i], style: const TextStyle(fontSize: 30)),
            ),
          ),
      ]),
    ]);
  }
}
