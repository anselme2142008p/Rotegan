import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

class ConnectFour extends BoardGame {
  static const int cols = 7;
  static const int rows = 6;

  // _g[ligne][colonne], ligne 0 = haut. -1 = vide.
  final List<List<int>> _g =
      List.generate(rows, (_) => List.filled(cols, -1));
  int _current = 0;
  int? _winner;
  bool _over = false;

  @override
  int get currentPlayer => _current;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  bool _colOpen(int c) => _g[0][c] == -1;

  int _dropRow(int c) {
    for (var r = rows - 1; r >= 0; r--) {
      if (_g[r][c] == -1) return r;
    }
    return -1;
  }

  @override
  List<Move> legalMoves() => _over
      ? []
      : [
          for (var c = 0; c < cols; c++)
            if (_colOpen(c)) {'col': c}
        ];

  @override
  void play(Move move) {
    final c = move['col'] as int;
    final r = _dropRow(c);
    _g[r][c] = _current;
    if (_wins(r, c, _current)) {
      _winner = _current;
      _over = true;
    } else if (legalMoves().isEmpty) {
      _over = true;
    } else {
      _current = 1 - _current;
    }
  }

  bool _wins(int r, int c, int p) {
    for (final d in const [
      [0, 1],
      [1, 0],
      [1, 1],
      [1, -1]
    ]) {
      var n = 1;
      for (final s in const [1, -1]) {
        var rr = r + d[0] * s, cc = c + d[1] * s;
        while (rr >= 0 && rr < rows && cc >= 0 && cc < cols && _g[rr][cc] == p) {
          n++;
          rr += d[0] * s;
          cc += d[1] * s;
        }
      }
      if (n >= 4) return true;
    }
    return false;
  }

  @override
  Move botMove(Random rnd) {
    final me = _current, opp = 1 - me;
    final moves = [
      for (var c = 0; c < cols; c++)
        if (_colOpen(c)) c
    ];

    bool wouldWin(int c, int p) {
      final r = _dropRow(c);
      _g[r][c] = p;
      final w = _wins(r, c, p);
      _g[r][c] = -1;
      return w;
    }

    // Offrir une victoire à l'adversaire juste au-dessus ?
    bool gives(int c) {
      final r = _dropRow(c);
      if (r == 0) return false;
      _g[r][c] = me;
      final bad = wouldWin(c, opp);
      _g[r][c] = -1;
      return bad;
    }

    for (final c in moves) {
      if (wouldWin(c, me)) return {'col': c}; // gagner
    }
    for (final c in moves) {
      if (wouldWin(c, opp)) return {'col': c}; // bloquer
    }
    final safe = moves.where((c) => !gives(c)).toList();
    final pool = safe.isEmpty ? moves : safe;
    pool.sort((a, b) => (a - 3).abs().compareTo((b - 3).abs()));
    final bestDist = (pool.first - 3).abs();
    final top = pool.where((c) => (c - 3).abs() <= bestDist + 1).toList();
    return {'col': top[rnd.nextInt(top.length)]};
  }

  @override
  String describe() => [for (final row in _g) row.map((v) => v == -1 ? '.' : (v == 0 ? 'R' : 'J')).join(' ')].join('\n');

  @override
  Widget buildBoard(
    BuildContext context, {
    required bool canPlay,
    required void Function(Move) onMove,
  }) {
    Color colorOf(int v) =>
        v == -1 ? Theme.of(context).scaffoldBackgroundColor : (v == 0 ? Colors.red : Colors.amber);

    return AspectRatio(
      aspectRatio: cols / rows,
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: Colors.blue.shade700,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            for (var c = 0; c < cols; c++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: (canPlay && !_over && _colOpen(c))
                      ? () => onMove({'col': c})
                      : null,
                  child: Column(
                    children: [
                      for (var r = 0; r < rows; r++)
                        Expanded(
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(2),
                              child: AspectRatio(
                                aspectRatio: 1,
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: colorOf(_g[r][c]),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
