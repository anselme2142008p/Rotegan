import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Serpents et échelles, 2 à 6 joueurs : course jusqu'à la case 100. Le dé fait partie du coup : {'d': 1 à 6}
/// (ainsi tous les téléphones jouent exactement la même partie).
class Snakes extends BoardGame {
  static const _jumps = {
    1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100,
    16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78,
  };
  static const _cols = [Colors.red, Colors.amber, Colors.blue, Colors.green, Colors.purple, Colors.orange];
  static const _names = ['rouge', 'jaune', 'bleu', 'vert', 'violet', 'orange'];

  int _np = 2, _cur = 0;
  List<int> _pos = [0, 0];
  int? _winner;
  bool _over = false;
  String _msg = '';

  @override
  void setPlayers(int n) {
    _np = n;
    _pos = List.filled(n, 0);
    _cur = 0;
  }

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over ? [] : [for (var d = 1; d <= 6; d++) {'d': d}];

  @override
  void play(Move move) {
    final d = move['d'] as int;
    var t = _pos[_cur] + d;
    var msg = 'J${_cur + 1} (${_names[_cur]}) lance $d';
    if (t > 100) {
      t = _pos[_cur];
      msg += ' : trop haut, il reste sur place.';
    } else if (_jumps.containsKey(t)) {
      final j = _jumps[t]!;
      msg += j > t ? ' : échelle ↑ $j' : ' : serpent ↓ $j';
      t = j;
    }
    _pos[_cur] = t;
    _msg = msg;
    if (t == 100) {
      _over = true;
      _winner = _cur;
    } else {
      _cur = (_cur + 1) % _np;
    }
  }

  @override
  Move botMove(Random rnd) => {'d': 1 + rnd.nextInt(6)};

  @override
  String describe() => 'Cases : ${[for (var i = 0; i < _np; i++) 'J${i + 1} ${_pos[i]}'].join(', ')}. $_msg';

  Widget _dot(Color c) => Container(width: 8, height: 8, margin: const EdgeInsets.all(1), decoration: BoxDecoration(shape: BoxShape.circle, color: c));

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    final base = Theme.of(context).colorScheme.secondaryContainer;
    return Column(children: [
      AspectRatio(
        aspectRatio: 1,
        child: GridView.count(
          crossAxisCount: 10,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (var r = 9; r >= 0; r--)
              for (var c = 0; c < 10; c++) _cell(r * 10 + (r % 2 == 0 ? c + 1 : 10 - c), base),
          ],
        ),
      ),
      const SizedBox(height: 8),
      Wrap(spacing: 12, children: [
        for (var i = 0; i < _np; i++)
          Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.circle, size: 12, color: _cols[i]),
            Text(' J${i + 1} : case ${_pos[i]}', style: Theme.of(context).textTheme.bodySmall),
          ]),
      ]),
      if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(_msg, textAlign: TextAlign.center)),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: canPlay && !_over ? () => onMove({'d': Random().nextInt(6) + 1}) : null,
        child: const Text('🎲 Lancer le dé'),
      ),
    ]);
  }

  Widget _cell(int n, Color base) {
    final j = _jumps[n];
    return Container(
      margin: const EdgeInsets.all(.5),
      color: j == null ? base : (j > n ? Colors.green.withOpacity(.3) : Colors.red.withOpacity(.28)),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('$n', style: const TextStyle(fontSize: 8)),
          if (j != null) Text('${j > n ? '↑' : '↓'}$j', style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold)),
          Wrap(children: [for (var i = 0; i < _np; i++) if (_pos[i] == n) _dot(_cols[i])]),
        ]),
      ),
    );
  }
}
