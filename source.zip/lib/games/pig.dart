import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Le Cochon (jeu de dés), 2 à 6 joueurs : on lance le dé autant qu'on veut et on cumule ;
/// un 1 fait tout perdre pour le tour ; on peut « garder » son total. Premier à 100 points.
/// Coups : {'a': 'r', 'd': dé} (lancer) ou {'a': 'h'} (garder).
class Pig extends BoardGame {
  int _np = 2, _cur = 0, _turn = 0, _last = 0;
  List<int> _sc = [0, 0];
  int? _winner;
  bool _over = false;
  String _msg = '';

  @override
  void setPlayers(int n) {
    _np = n;
    _sc = List.filled(n, 0);
    _cur = 0;
    _turn = 0;
  }

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over
      ? []
      : [
          for (var d = 1; d <= 6; d++) {'a': 'r', 'd': d},
          if (_turn > 0) {'a': 'h'},
        ];

  @override
  void play(Move move) {
    if (move['a'] == 'r') {
      final d = move['d'] as int;
      _last = d;
      if (d == 1) {
        _msg = 'J${_cur + 1} fait 1 : il perd son total du tour.';
        _turn = 0;
        _cur = (_cur + 1) % _np;
      } else {
        _turn += d;
        _msg = 'J${_cur + 1} fait $d.';
      }
      return;
    }
    _sc[_cur] += _turn;
    _msg = 'J${_cur + 1} garde $_turn points.';
    _turn = 0;
    if (_sc[_cur] >= 100) {
      _over = true;
      _winner = _cur;
      return;
    }
    _cur = (_cur + 1) % _np;
  }

  @override
  Move botMove(Random rnd) {
    if (_turn > 0 && (_turn >= 20 || _sc[_cur] + _turn >= 100)) return {'a': 'h'};
    return {'a': 'r', 'd': 1 + rnd.nextInt(6)};
  }

  @override
  String describe() => 'Cochon : ${[for (var i = 0; i < _np; i++) 'J${i + 1} ${_sc[i]}'].join(', ')} ; total du tour $_turn. $_msg';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    final t = Theme.of(context).textTheme;
    return Column(children: [
      for (var i = 0; i < _np; i++)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Text('J${i + 1} : ${_sc[i]} points${i == _cur && !_over ? '  ◀' : ''}', style: t.titleSmall),
        ),
      const SizedBox(height: 12),
      Text('Total du tour : $_turn', style: t.titleMedium),
      Text(_last == 0 ? '🎲' : '🎲 $_last', style: const TextStyle(fontSize: 30)),
      if (_msg.isNotEmpty) Text(_msg, textAlign: TextAlign.center),
      const SizedBox(height: 12),
      Wrap(spacing: 10, children: [
        FilledButton(
          onPressed: canPlay && !_over ? () => onMove({'a': 'r', 'd': Random().nextInt(6) + 1}) : null,
          child: const Text('🎲 Lancer'),
        ),
        FilledButton.tonal(
          onPressed: canPlay && !_over && _turn > 0 ? () => onMove({'a': 'h'}) : null,
          child: Text('Garder $_turn'),
        ),
      ]),
    ]);
  }
}
