import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Othello (Reversi) : on encadre les pions adverses pour les retourner.
/// Coup = {'cell': ligne * 8 + colonne}.
class Othello extends BoardGame {
  final List<List<int>> _b = List.generate(8, (_) => List.filled(8, -1));
  int _cur = 0;
  int? _winner;
  bool _over = false;

  Othello() {
    _b[3][3] = 1;
    _b[4][4] = 1;
    _b[3][4] = 0;
    _b[4][3] = 0;
  }

  static const _dirs = [
    [-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1],
  ];

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  bool _in(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;

  List<List<int>> _flips(int r, int c, int p) {
    if (_b[r][c] != -1) return [];
    final out = <List<int>>[];
    for (final d in _dirs) {
      final line = <List<int>>[];
      var rr = r + d[0], cc = c + d[1];
      while (_in(rr, cc) && _b[rr][cc] == 1 - p) {
        line.add([rr, cc]);
        rr += d[0];
        cc += d[1];
      }
      if (line.isNotEmpty && _in(rr, cc) && _b[rr][cc] == p) out.addAll(line);
    }
    return out;
  }

  List<int> _cells(int p) => [
        for (var r = 0; r < 8; r++)
          for (var c = 0; c < 8; c++)
            if (_flips(r, c, p).isNotEmpty) r * 8 + c
      ];

  int _count(int p) => _b.expand((row) => row).where((v) => v == p).length;

  @override
  List<Move> legalMoves() => _over ? [] : [for (final k in _cells(_cur)) {'cell': k}];

  @override
  void play(Move move) {
    final k = move['cell'] as int, r = k ~/ 8, c = k % 8, me = _cur;
    for (final f in _flips(r, c, me)) {
      _b[f[0]][f[1]] = me;
    }
    _b[r][c] = me;
    if (_cells(1 - me).isNotEmpty) {
      _cur = 1 - me;
    } else if (_cells(me).isEmpty) {
      // Personne ne peut jouer : fin de partie.
      _over = true;
      final a = _count(0), z = _count(1);
      _winner = a > z ? 0 : (z > a ? 1 : null);
    } // sinon l'adversaire passe son tour et on rejoue
  }

  @override
  Move botMove(Random rnd) {
    double best = -1e9;
    var pick = -1;
    for (final k in _cells(_cur)) {
      final r = k ~/ 8, c = k % 8, f = _flips(r, c, _cur).length;
      final corner = r % 7 == 0 && c % 7 == 0;
      final edge = r % 7 == 0 || c % 7 == 0;
      final near = (r == 1 || r == 6) && (c == 1 || c == 6);
      final sc = f + (corner ? 50 : 0) + (edge ? 5 : 0) - (near ? 10 : 0) + rnd.nextDouble() * 2;
      if (sc > best) {
        best = sc;
        pick = k;
      }
    }
    return {'cell': pick};
  }

  @override
  String describe() =>
      [for (final row in _b) row.map((v) => v == -1 ? '.' : (v == 0 ? 'N' : 'B')).join(' ')].join('\n') + '\nN=${_count(0)} B=${_count(1)}';

  @override
  Widget buildBoard(BuildContext context,
      {required bool canPlay, required void Function(Move) onMove}) {
    final mv = canPlay && !_over ? _cells(_cur).toSet() : <int>{};
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(color: const Color(0xFF1B5E3A), borderRadius: BorderRadius.circular(12)),
        child: GridView.count(
          crossAxisCount: 8,
          mainAxisSpacing: 2,
          crossAxisSpacing: 2,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (var k = 0; k < 64; k++)
              GestureDetector(
                onTap: mv.contains(k) ? () => onMove({'cell': k}) : null,
                child: Container(
                  color: const Color(0xFF2E7D4F),
                  alignment: Alignment.center,
                  child: _b[k ~/ 8][k % 8] != -1
                      ? FractionallySizedBox(
                          widthFactor: .78,
                          heightFactor: .78,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _b[k ~/ 8][k % 8] == 0 ? const Color(0xFF111111) : const Color(0xFFF4F4F4),
                            ),
                          ),
                        )
                      : (mv.contains(k)
                          ? FractionallySizedBox(
                              widthFactor: .24,
                              heightFactor: .24,
                              child: DecoratedBox(
                                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.45)),
                              ),
                            )
                          : null),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
