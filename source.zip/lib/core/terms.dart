/// Message affiché à la première connexion (et à chaque nouvelle version).
/// À faire relire et compléter (contact, mentions légales) avant la publication de l’application.
const int termsVersion = 1;

const List<List<String>> termsSections = [
  [
    'Bienvenue',
    'Rotegan réunit de nombreux jeux de société que tu peux jouer seul contre l’ordinateur, à deux sur le même téléphone, en réseau local ou en ligne. Avant de continuer, prends un moment pour lire comment les choses fonctionnent.',
  ],
  [
    'Ton compte et ton profil',
    'Pour jouer en ligne, tu crées un compte avec une adresse e-mail et un mot de passe. Ton profil contient un pseudo, une nationalité (facultative) et une photo (facultative). Ton pseudo, ton pays, ta photo et tes victoires sont visibles par les autres joueurs. Tu peux les modifier à tout moment depuis « Mon profil ».',
  ],
  [
    'Trouver un adversaire',
    'Quand tu lances une partie rapide, l’application te met avec un joueur humain déjà en attente. S’il n’y a personne après environ 10 secondes, elle te connecte automatiquement à un joueur virtuel pour que tu puisses jouer sans attendre.',
  ],
  [
    'Les joueurs virtuels (IA)',
    'Les joueurs virtuels sont des programmes pilotés par une intelligence artificielle, pas des personnes. Ils ont un nom, un pays et un avatar fictifs. Pendant la partie, rien ne le rappelle à l’écran pour ne pas la gêner, mais tu peux le vérifier à tout moment : touche l’icône « i » en haut de la partie pour ouvrir la fiche de ton adversaire, qui indique « Joueur virtuel (IA) » et son niveau. Si tu demandes sincèrement à l’un d’eux s’il est une IA, il te répond honnêtement. Ils ne gagnent pas à chaque fois, et ils ne participent pas aux appels vocaux.',
  ],
  [
    'Discuter pendant la partie',
    'Tu peux écrire à ton adversaire pendant la partie. Contre un joueur humain, il reçoit tes messages. Contre un joueur virtuel, tes messages et un résumé de la partie en cours sont envoyés à un service d’intelligence artificielle externe (Google Gemini) pour préparer sa réponse, qui arrive en général après une vingtaine de secondes. N’écris jamais d’informations personnelles (adresse, numéro de téléphone, mots de passe). Sois respectueux : les insultes et le harcèlement ne sont pas acceptés.',
  ],
  [
    'Appel vocal',
    'Pendant une partie en ligne contre un autre joueur humain, vous pouvez vous appeler. Le son passe directement d’un téléphone à l’autre et n’est pas enregistré par l’application. Cette connexion directe peut révéler ton adresse réseau (adresse IP) à l’autre joueur. Tu peux refuser ou raccrocher à tout moment, et l’application te demande l’accès au micro seulement quand tu appelles ou réponds.',
  ],
  [
    'Scores',
    'Tes victoires sont enregistrées sur ton compte, y compris celles obtenues contre un joueur virtuel.',
  ],
  [
    'Tes données',
    'L’application enregistre ton adresse e-mail, ton profil, tes parties en ligne, tes messages de chat et tes scores, sur les serveurs du service Supabase. Pour demander la suppression de ton compte ou de tes données, écris à : [adresse de contact à compléter].',
  ],
  [
    'Ton accord',
    'En appuyant sur « J’ai lu et j’accepte », tu confirmes avoir compris ces règles, en particulier la possibilité de jouer contre des joueurs virtuels et l’envoi de tes messages de chat à un service d’IA externe. Si tu refuses, tu peux continuer à jouer hors ligne, mais pas en ligne.',
  ],
];
