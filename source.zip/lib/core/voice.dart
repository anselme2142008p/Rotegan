import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'online.dart';

enum CallState { idle, calling, incoming, connected }

/// Appel vocal entre les deux joueurs d'une salle : l'audio passe directement de
/// téléphone à téléphone (WebRTC) ; Supabase Realtime ne sert qu'à s'échanger
/// les messages de mise en relation (offre, réponse, candidats ICE).
class VoiceCall extends ChangeNotifier {
  final String roomId;
  CallState state = CallState.idle;
  bool muted = false;
  late final RealtimeChannel _ch;
  RTCPeerConnection? _pc;
  MediaStream? _local;
  RTCSessionDescription? _offer;
  final List<RTCIceCandidate> _ice = [];
  bool _remoteSet = false;
  bool _disposed = false;

  VoiceCall(this.roomId) {
    _ch = sb.channel('call_$roomId').onBroadcast(event: 'sig', callback: _onSig).subscribe();
  }

  void _set(CallState s) {
    state = s;
    if (!_disposed) notifyListeners();
  }

  void _send(Map<String, dynamic> m) {
    try {
      _ch.sendBroadcastMessage(event: 'sig', payload: m);
    } catch (_) {}
  }

  Future<RTCPeerConnection> _makePc() async {
    final pc = await createPeerConnection({
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'},
      ],
    });
    pc.onIceCandidate = (c) {
      if (c.candidate != null) _send({'t': 'ice', 'c': c.toMap()});
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        _set(CallState.connected);
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
        _reset();
      }
    };
    for (final t in _local!.getAudioTracks()) {
      await pc.addTrack(t, _local!);
    }
    return pc;
  }

  Future<void> _openMic() async {
    _local = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': false});
  }

  /// Lance l'appel (l'autre joueur doit répondre).
  Future<void> call() async {
    await _openMic();
    _pc = await _makePc();
    final o = await _pc!.createOffer();
    await _pc!.setLocalDescription(o);
    _send({'t': 'offer', 'sdp': o.sdp, 'type': o.type});
    _set(CallState.calling);
  }

  /// Répond à un appel entrant.
  Future<void> accept() async {
    if (_offer == null) return;
    await _openMic();
    _pc = await _makePc();
    await _pc!.setRemoteDescription(_offer!);
    _remoteSet = true;
    await _flushIce();
    final a = await _pc!.createAnswer();
    await _pc!.setLocalDescription(a);
    _send({'t': 'answer', 'sdp': a.sdp, 'type': a.type});
  }

  Future<void> _flushIce() async {
    for (final c in _ice) {
      await _pc?.addCandidate(c);
    }
    _ice.clear();
  }

  Future<void> _onSig(Map<String, dynamic> raw) async {
    try {
      final m = raw['payload'] is Map ? Map<String, dynamic>.from(raw['payload'] as Map) : raw;
      switch (m['t']) {
        case 'offer':
          if (state == CallState.idle) {
            _offer = RTCSessionDescription(m['sdp'] as String?, m['type'] as String?);
            _set(CallState.incoming);
          }
        case 'answer':
          await _pc?.setRemoteDescription(RTCSessionDescription(m['sdp'] as String?, m['type'] as String?));
          _remoteSet = true;
          await _flushIce();
        case 'ice':
          final c = Map<String, dynamic>.from(m['c'] as Map);
          final cand = RTCIceCandidate(c['candidate'] as String?, c['sdpMid'] as String?, c['sdpMLineIndex'] as int?);
          if (_remoteSet && _pc != null) {
            await _pc!.addCandidate(cand);
          } else {
            _ice.add(cand);
          }
        case 'hangup':
          _reset();
      }
    } catch (_) {}
  }

  void toggleMute() {
    muted = !muted;
    for (final t in _local?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !muted;
    }
    if (!_disposed) notifyListeners();
  }

  /// Raccroche, annule ou refuse.
  void hangup() {
    _send({'t': 'hangup'});
    _reset();
  }

  void _reset() {
    _pc?.close();
    _pc = null;
    for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    _local?.dispose();
    _local = null;
    _offer = null;
    _remoteSet = false;
    _ice.clear();
    muted = false;
    _set(CallState.idle);
  }

  @override
  void dispose() {
    _disposed = true;
    _pc?.close();
    for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    sb.removeChannel(_ch);
    super.dispose();
  }
}
