import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// Un coup est un petit dictionnaire JSON, ex: {'cell': 4} ou {'col': 3}.
/// Ainsi il peut être envoyé tel quel par le réseau (LAN / en ligne).
typedef Move = Map<String, dynamic>;

/// Contrat que doit respecter chaque jeu de société.
abstract class BoardGame {
  int get currentPlayer;
  bool get isOver;

  /// Gagnant (0 ou 1). null = match nul ou partie en cours.
  int? get winner;

  List<Move> legalMoves();
  void play(Move move);
  Move botMove(Random rnd);

  Widget buildBoard(
    BuildContext context, {
    required bool canPlay,
    required void Function(Move) onMove,
  });

  /// Graine commune aux deux joueurs (jeux avec de l'aléa, comme Mémoire).
  void seed(int s) {}

  /// Nombre de joueurs de la partie (jeux de 3 joueurs et plus).
  void setPlayers(int n) {}

  /// Plateau en texte (pour que le joueur virtuel sache où en est la partie).
  String describe() => '';

  bool isLegal(Move move) => legalMoves().any((m) => mapEquals(m, move));
}

/// Fiche descriptive d'un jeu, utilisée par le menu.
class GameDef {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final int minPlayers;
  final int maxPlayers;
  final BoardGame Function() create;
  final String category;

  const GameDef({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.minPlayers,
    required this.maxPlayers,
    required this.create,
    this.category = 'Autres',
  });
}
