import 'dart:convert';
import 'dart:io';

/// Lien avec un adversaire distant (LAN ou en ligne). Le contrôleur de partie
/// ne connaît que cette interface : un jeu marche donc partout sans changement.
abstract class GameLink {
  @override
  set onMessage(void Function(Map<String, dynamic>)? handler);
  void send(Map<String, dynamic> msg);
  void close();
}

/// Connexion TCP à un adversaire sur le réseau local.
/// Les messages sont du JSON, un message par ligne.
class LanConnection implements GameLink {
  final Socket _socket;
  final List<Map<String, dynamic>> _pending = [];
  void Function(Map<String, dynamic>)? _handler;
  bool _closed = false;

  LanConnection(this._socket) {
    _socket
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
      (line) {
        Map<String, dynamic>? msg;
        try {
          msg = jsonDecode(line) as Map<String, dynamic>;
        } catch (_) {}
        if (msg != null) _emit(msg);
      },
      onDone: () {
        if (!_closed) _emit({'type': 'closed'});
      },
      onError: (_) {
        if (!_closed) _emit({'type': 'closed'});
      },
    );
  }

  /// Les messages reçus avant qu'un écouteur existe sont mis en attente.
  @override
  set onMessage(void Function(Map<String, dynamic>)? handler) {
    _handler = handler;
    _flush();
  }

  void _emit(Map<String, dynamic> msg) {
    _pending.add(msg);
    _flush();
  }

  void _flush() {
    while (_handler != null && _pending.isNotEmpty) {
      _handler!(_pending.removeAt(0));
    }
  }

  @override
  void send(Map<String, dynamic> msg) {
    if (_closed) return;
    try {
      _socket.write('${jsonEncode(msg)}\n');
    } catch (_) {}
  }

  @override
  void close() {
    _closed = true;
    _socket.destroy();
  }
}

/// Côté hôte : ouvre le port et attend un joueur.
class LanHost {
  static const int port = 4040;
  ServerSocket? _server;

  static Future<List<String>> localIps() async {
    final ifaces = await NetworkInterface.list(
      type: InternetAddressType.IPv4,
      includeLoopback: false,
    );
    return [
      for (final i in ifaces)
        for (final a in i.addresses) a.address
    ];
  }

  Future<LanConnection> waitForPlayer() async {
    final server =
        await ServerSocket.bind(InternetAddress.anyIPv4, port, shared: true);
    _server = server;
    final socket = await server.first;
    await server.close();
    return LanConnection(socket);
  }

  /// Parties à plus de 2 joueurs : chaque joueur qui se connecte est signalé à onPeer.
  Future<void> listen(void Function(LanConnection) onPeer) async {
    final server = await ServerSocket.bind(InternetAddress.anyIPv4, port, shared: true);
    _server = server;
    server.listen((s) => onPeer(LanConnection(s)));
  }

  void cancel() => _server?.close();
}

/// Côté invité : se connecte à l'IP de l'hôte.
class LanClient {
  static Future<LanConnection> connect(String ip) async {
    final socket = await Socket.connect(
      ip,
      LanHost.port,
      timeout: const Duration(seconds: 5),
    );
    return LanConnection(socket);
  }
}

/// Hôte d'une partie à plusieurs joueurs : il reçoit les coups de chacun et les relaie à tous les autres.
class LanHub implements GameLink {
  final List<LanConnection> peers;
  void Function(Map<String, dynamic>)? _handler;
  final List<Map<String, dynamic>> _pending = [];

  LanHub(this.peers) {
    for (final p in peers) {
      p.onMessage = (m) {
        final t = m['type'];
        if (t == 'move' || t == 'closed') {
          for (final q in peers) {
            if (q != p) q.send(m);
          }
        }
        _pending.add(m);
        _flush();
      };
    }
  }

  @override
  set onMessage(void Function(Map<String, dynamic>)? handler) {
    _handler = handler;
    _flush();
  }

  void _flush() {
    while (_handler != null && _pending.isNotEmpty) {
      _handler!(_pending.removeAt(0));
    }
  }

  @override
  void send(Map<String, dynamic> msg) {
    for (final p in peers) {
      p.send(msg);
    }
  }

  @override
  void close() {
    for (final p in peers) {
      p.close();
    }
  }
}
