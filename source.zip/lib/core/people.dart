import 'package:flutter/material.dart';

/// Ce qu'on affiche d'un joueur : nom, nationalité, photo (ou avatar), IA ou humain.
class PlayerInfo {
  final String name;
  final String? country; // code pays à 2 lettres, ex. « BJ »
  final String? avatarUrl; // photo de profil (joueurs humains)
  final String? emoji; // avatar des joueurs IA
  final Color? color;
  final bool isBot;
  final int level; // 1 facile, 2 moyen, 3 difficile (IA)
  final String? greeting;
  final int? botId; // numéro dans ai_players
  final bool isMe;

  const PlayerInfo({
    required this.name,
    this.country,
    this.avatarUrl,
    this.emoji,
    this.color,
    this.isBot = false,
    this.level = 3,
    this.greeting,
    this.botId,
    this.isMe = false,
  });
}

const Map<String, String> countries = {
  'BJ': 'Bénin', 'TG': 'Togo', 'NG': 'Nigeria', 'GH': 'Ghana', 'CI': 'Côte d’Ivoire',
  'SN': 'Sénégal', 'ML': 'Mali', 'BF': 'Burkina Faso', 'NE': 'Niger', 'CM': 'Cameroun',
  'GA': 'Gabon', 'CG': 'Congo', 'CD': 'RD Congo', 'MA': 'Maroc', 'DZ': 'Algérie',
  'TN': 'Tunisie', 'EG': 'Égypte', 'ZA': 'Afrique du Sud', 'KE': 'Kenya', 'FR': 'France',
  'BE': 'Belgique', 'CH': 'Suisse', 'CA': 'Canada', 'US': 'États-Unis', 'GB': 'Royaume-Uni',
  'DE': 'Allemagne', 'ES': 'Espagne', 'IT': 'Italie', 'PT': 'Portugal', 'NL': 'Pays-Bas',
  'BR': 'Brésil', 'MX': 'Mexique', 'AR': 'Argentine', 'CO': 'Colombie', 'HT': 'Haïti',
  'TR': 'Turquie', 'RU': 'Russie', 'UA': 'Ukraine', 'CN': 'Chine', 'JP': 'Japon',
  'KR': 'Corée du Sud', 'IN': 'Inde', 'PK': 'Pakistan', 'ID': 'Indonésie', 'VN': 'Viêt Nam',
  'SA': 'Arabie saoudite', 'LB': 'Liban', 'AU': 'Australie',
};

/// Drapeau en émoji, calculé à partir du code pays (aucune image nécessaire).
String flagOf(String? cc) => (cc == null || cc.length != 2)
    ? '🏳️'
    : String.fromCharCodes(cc.toUpperCase().codeUnits.map((c) => 0x1F1E6 + c - 65));

String countryName(String? cc) => countries[cc?.toUpperCase()] ?? 'Pays non renseigné';

const levelNames = ['', 'Facile', 'Moyen', 'Difficile'];

Color colorFromHex(String h) => Color(int.parse('FF${h.replaceAll('#', '')}', radix: 16));
