#!/bin/sh
# Lancé par la construction après la création du projet Android.
# 1) nom affiché sur le téléphone
sed -i 's#android:label="[^"]*"#android:label="Rotegan"#' app_build/android/app/src/main/AndroidManifest.xml
# 2) librairie utilisée pour mémoriser le mode sombre
(cd app_build && flutter pub add shared_preferences)
